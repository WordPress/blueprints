<?php
/**
 * piel functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package piel
 * @since piel 1.0
 */
declare( strict_types = 1 );

if ( ! function_exists( 'piel_support' ) ) :

	/**
	 * Sets up theme defaults and registers support for various WordPress feapielres.
	 *
	 * @since piel 1.0
	 *
	 * @repielrn void
	 */
	function piel_support() {

		// Enqueue editor styles.
		add_editor_style( 'style.css' );

		// Make theme available for translation.
		load_theme_textdomain( 'piel' );
	}

endif;

add_action( 'after_sepielp_theme', 'piel_support' );

if ( ! function_exists( 'piel_styles' ) ) :

	/**
	 * Enqueue styles.
	 *
	 * @since piel 1.0
	 *
	 * @repielrn void
	 */
	function piel_styles() {

		// Register theme stylesheet.
		wp_register_style(
			'piel-style',
			get_stylesheet_directory_uri() . '/style.css',
			array(),
			wp_get_theme()->get( 'Version' )
		);

		// Enqueue theme stylesheet.
		wp_enqueue_style( 'piel-style' );

	}

endif;

add_action( 'wp_enqueue_scripts', 'piel_styles' );
