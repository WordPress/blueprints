<?php
/**
 * Title: A 404 page
 * Slug: piel/404
 * Inserter: no
 */
declare( strict_types = 1 );
?>

<!-- wp:heading {"level":1,"fontSize":"huge","anchor":"oops-that-page-can-t-be-found"} -->
<h1 class="wp-block-heading has-huge-font-size" id="oops-that-page-can-t-be-found"><?php echo esc_html__( 'Nothing found. Maybe try a search?', 'piel' ); ?></h1>
<!-- /wp:heading -->
