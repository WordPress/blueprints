<?php
/**
 * Title: Search
 * Slug: piel/search
 * Inserter: no
 */
declare( strict_types = 1 );
?>

<!-- wp:search {"label":"","showLabel":false,"placeholder":"<?php echo esc_html_x( 'Search...', 'This is a placeholder text in a search field', 'piel' ); ?>","buttonText":"Search","buttonUseIcon":true} /-->
