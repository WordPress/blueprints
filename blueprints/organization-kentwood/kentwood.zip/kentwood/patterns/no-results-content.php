<?php
/**
 * Title: No Results Content
 * Slug: kentwood/no-results-content
 * Inserter: no
 */
?>

<!-- wp:paragraph {"style":{"spacing":{"margin":{"bottom":"0px"}}}} -->
<p style="margin-bottom:0px"><?php echo esc_html_x( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'Message explaining that there are no results returned from a search', 'kentwood' ); ?></p>
<!-- /wp:paragraph -->
