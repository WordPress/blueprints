<?php
/**
 * Title: footer
 * Slug: readymade/footer
 * Inserter: no
 */
?>
<!-- wp:spacer {"height":"var:preset|spacing|70","metadata":{"name":"XL"}} -->
<div style="height:var(--wp--preset--spacing--70)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"metadata":{"name":"Footer Wrapper"},"layout":{"inherit":true,"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"metadata":{"name":"Footer Section Wrapper"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"metadata":{"name":"Section Title"},"style":{"typography":{"fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}},"fontSize":"small"} -->
<h2 class="wp-block-heading has-small-font-size" id="contact" style="margin-bottom:var(--wp--preset--spacing--40);font-style:normal;font-weight:700"><?php esc_html_e('Contact', 'readymade');?></h2>
<!-- /wp:heading -->

<!-- wp:columns {"metadata":{"name":"Link 1"}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p><?php esc_html_e('Figma', 'readymade');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline","style":{"typography":{"fontStyle":"normal","fontWeight":"600"}}} -->
<p class="no-underline" style="font-style:normal;font-weight:600"><?php /* Translators: 1. is the start of a 'a' HTML element, 2. is the end of a 'a' HTML element */ 
echo sprintf( esc_html__( '%1$scamillestudio%2$s', 'readymade' ), '<a href="' . esc_url( '#' ) . '">', '</a>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"metadata":{"name":"Link 2"}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p><?php esc_html_e('Instagram', 'readymade');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline","style":{"typography":{"fontStyle":"normal","fontWeight":"600"}}} -->
<p class="no-underline" style="font-style:normal;font-weight:600"><?php /* Translators: 1. is the start of a 'a' HTML element, 2. is the end of a 'a' HTML element */ 
echo sprintf( esc_html__( '%1$s@camille.rivera%2$s', 'readymade' ), '<a href="' . esc_url( '#' ) . '">', '</a>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"metadata":{"name":"Link 3"}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p><?php esc_html_e('Mastodon', 'readymade');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline","style":{"typography":{"fontStyle":"normal","fontWeight":"600"}}} -->
<p class="no-underline" style="font-style:normal;font-weight:600"><?php /* Translators: 1. is the start of a 'a' HTML element, 2. is the end of a 'a' HTML element */ 
echo sprintf( esc_html__( '%1$s@camille@design.social%2$s', 'readymade' ), '<a href="' . esc_url( '#' ) . '">', '</a>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"metadata":{"name":"Link 4"}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p><?php esc_html_e('Bluesky', 'readymade');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline","style":{"typography":{"fontStyle":"normal","fontWeight":"600"}}} -->
<p class="no-underline" style="font-style:normal;font-weight:600"><?php /* Translators: 1. is the start of a 'a' HTML element, 2. is the end of a 'a' HTML element */ 
echo sprintf( esc_html__( '%1$scamille.bsky.social%2$s', 'readymade' ), '<a href="' . esc_url( '#' ) . '">', '</a>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"metadata":{"name":"Link 5"}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p><?php esc_html_e('Linkedin', 'readymade');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline","style":{"typography":{"fontStyle":"normal","fontWeight":"600"}}} -->
<p class="no-underline" style="font-style:normal;font-weight:600"><?php /* Translators: 1. is the start of a 'a' HTML element, 2. is the end of a 'a' HTML element */ 
echo sprintf( esc_html__( '%1$scamille-rivera%2$s', 'readymade' ), '<a href="' . esc_url( '#' ) . '">', '</a>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"var:preset|spacing|70","metadata":{"name":"XL"}} -->
<div style="height:var(--wp--preset--spacing--70)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"isStackedOnMobile":false} -->
<div class="wp-block-columns is-not-stacked-on-mobile"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:site-title {"level":0,"className":"no-arrow","style":{"typography":{"fontStyle":"normal","fontWeight":"400"}},"fontSize":"small"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"align":"left","className":"no-arrow","fontSize":"small"} -->
<p class="has-text-align-left no-arrow has-small-font-size"><?php /* Translators: 1. is the start of a 'a' HTML element, 2. is the end of a 'a' HTML element */ 
echo sprintf( esc_html__( 'Designed with %1$sWordPress%2$s', 'readymade' ), '<a href="' . esc_url( 'https://wordpress.org' ) . '" rel="nofollow">', '</a>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"var:preset|spacing|50","metadata":{"name":"M"}} -->
<div style="height:var(--wp--preset--spacing--50)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->