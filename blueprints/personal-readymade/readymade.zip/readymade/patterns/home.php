<?php
/**
 * Title: home
 * Slug: readymade/home
 * Inserter: no
 */
?>
<!-- wp:template-part {"slug":"header","tagName":"header"} /-->

<!-- wp:group {"tagName":"main","metadata":{"name":"Content"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<main class="wp-block-group" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"metadata":{"name":"Section - About"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"metadata":{"name":"Section Title"},"style":{"typography":{"fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}},"fontSize":"small"} -->
<h2 class="wp-block-heading has-small-font-size" id="about" style="margin-bottom:var(--wp--preset--spacing--40);font-style:normal;font-weight:700">About</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>I’m a multidisciplinary designer with a background in communication and visual storytelling. My approach combines empathy and clarity to design intuitive digital experiences. I believe every interaction tells a story — let’s make it a memorable one.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"var:preset|spacing|70","metadata":{"name":"XL"}} -->
<div style="height:var(--wp--preset--spacing--70)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"metadata":{"name":"Section - Blog"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"metadata":{"name":"Section Title"},"style":{"typography":{"fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}},"fontSize":"small"} -->
<h2 class="wp-block-heading has-small-font-size" id="blog" style="margin-bottom:var(--wp--preset--spacing--40);font-style:normal;font-weight:700">Notes &amp; Reflections</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":9,"query":{"perPage":1,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"metadata":{"categories":["posts"],"patternName":"core/query-small-posts","name":"Small image and title"}} -->
<div class="wp-block-query"><!-- wp:post-template -->
<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"blockGap":{"top":"var:preset|spacing|30","left":"0"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center" style="margin-top:0;margin-bottom:0"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:post-featured-image {"isLink":true,"aspectRatio":"4/3","width":"90px","className":"no-arrow"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":""} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:post-title {"level":3,"isLink":true} /-->

<!-- wp:post-date {"fontSize":"medium"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<!-- /wp:post-template --></div>
<!-- /wp:query --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"var:preset|spacing|70","metadata":{"name":"XL"}} -->
<div style="height:var(--wp--preset--spacing--70)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"metadata":{"name":"Section - Work Experience"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"metadata":{"name":"Section Title"},"style":{"typography":{"fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}},"fontSize":"small"} -->
<h2 class="wp-block-heading has-small-font-size" id="work" style="margin-bottom:var(--wp--preset--spacing--40);font-style:normal;font-weight:700">Work Experience</h2>
<!-- /wp:heading -->

<!-- wp:group {"metadata":{"name":"Entry 1"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p>2020 — Now</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline"} -->
<p class="no-underline"><a href="#">Lead Product Designer at Studio North</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Led end-to-end design for 15+ SaaS platforms. Mentored a team of 5 designers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>New York, NY</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"var:preset|spacing|60","metadata":{"name":"L"}} -->
<div style="height:var(--wp--preset--spacing--60)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Entry 2"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p>2017 — 2020</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline"} -->
<p class="no-underline"><a href="#">UX/UI Designer at Halo Labs</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Designed interfaces for AR applications and prototyped VR experiences.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Remote</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"var:preset|spacing|50","metadata":{"name":"M"}} -->
<div style="height:var(--wp--preset--spacing--50)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"metadata":{"name":"Portfolio Row"},"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","style":{"layout":{"selfStretch":"fixed","flexSize":"90px"}}} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/rm-screenshot-theme-vueo.png" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none","style":{"layout":{"selfStretch":"fixed","flexSize":"90px"}}} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/rm-screenshot-theme-massimo.png" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none","style":{"layout":{"selfStretch":"fixed","flexSize":"90px"}}} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/rm-screenshot-theme-specials.png" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none","style":{"layout":{"selfStretch":"fixed","flexSize":"90px"}}} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/rm-screenshot-theme-professio.png" alt=""/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"var:preset|spacing|60","metadata":{"name":"L"}} -->
<div style="height:var(--wp--preset--spacing--60)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Entry 3"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p>2014 — 2015</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline"} -->
<p class="no-underline"><a href="#">Design Apprentice at Forma Interactive</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Supported interaction and motion design for mobile apps.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Boston, MA</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"var:preset|spacing|70","metadata":{"name":"XL"}} -->
<div style="height:var(--wp--preset--spacing--70)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"metadata":{"name":"Section - Education"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"metadata":{"name":"Section Title"},"style":{"typography":{"fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}},"fontSize":"small"} -->
<h2 class="wp-block-heading has-small-font-size" id="education" style="margin-bottom:var(--wp--preset--spacing--40);font-style:normal;font-weight:700">Education</h2>
<!-- /wp:heading -->

<!-- wp:group {"metadata":{"name":"Entry 1"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p>2011 — 2013</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p>MFA in Design &amp; Technology</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Parsons School of Design, NY</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"var:preset|spacing|60","metadata":{"name":"L"}} -->
<div style="height:var(--wp--preset--spacing--60)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"metadata":{"name":"Entry 2"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p>2007 — 2011</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p>BA in Media Arts &amp; Design</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>University of Virginia, VA</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"var:preset|spacing|70","metadata":{"name":"XL"}} -->
<div style="height:var(--wp--preset--spacing--70)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"metadata":{"name":"Section - Writing"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"metadata":{"name":"Section Title"},"style":{"typography":{"fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}},"fontSize":"small"} -->
<h2 class="wp-block-heading has-small-font-size" id="writing" style="margin-bottom:var(--wp--preset--spacing--40);font-style:normal;font-weight:700">Writing</h2>
<!-- /wp:heading -->

<!-- wp:group {"metadata":{"name":"Entry 1"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p>2024</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline"} -->
<p class="no-underline"><a href="#">Beyond the Screen: Designing for Emotion</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"no-underline"} -->
<p class="no-underline"><a href="#">What Makes an Experience “Feel” Right?</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"var:preset|spacing|60","metadata":{"name":"L"}} -->
<div style="height:var(--wp--preset--spacing--60)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"metadata":{"name":"Entry 2"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p>2023</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline"} -->
<p class="no-underline"><a href="#">Creating with Constraints</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"no-underline"} -->
<p class="no-underline"><a href="#">Minimal Interfaces, Maximum Impact</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"var:preset|spacing|60","metadata":{"name":"L"}} -->
<div style="height:var(--wp--preset--spacing--60)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Entry 2"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"110px"} -->
<div class="wp-block-column" style="flex-basis:110px"><!-- wp:paragraph {"metadata":{"name":"Date"}} -->
<p>2022</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"no-underline"} -->
<p class="no-underline"><a href="#">Mapping the Invisible: User Flows and Mental Models</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></main>
<!-- /wp:group -->

<!-- wp:template-part {"slug":"footer","tagName":"footer"} /-->