<?php
/**
 * Title: post-meta
 * Slug: readymade/post-meta
 * Inserter: no
 */
?>
<!-- wp:group {"metadata":{"name":"Post Meta Wrapper"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex"}} -->
<div class="wp-block-group"><!-- wp:post-date /-->

<!-- wp:paragraph {"metadata":{"name":"|"},"fontSize":"small"} -->
<p class="has-small-font-size"><?php esc_html_e('|', 'readymade');?></p>
<!-- /wp:paragraph -->

<!-- wp:post-author {"showAvatar":false,"fontSize":"small"} /-->

<!-- wp:post-terms {"term":"category","fontSize":"small"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->