== Readymade ==

Contributors: Automattic
Requires at least: 6.8
Tested up to: 6.8
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Changelog ==

= 1.0.0 =
* Initial release


== Copyright ==

Readymade WordPress Theme, (C) 2025 Automattic
Readymade is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


Readymade is based on Block Canvas (https://github.com/Automattic/themes/tree/trunk/block-canvas), (C) Automattic, [GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)


== Description ==

Clean, organized, and highly readable, this theme is perfect for showcasing your career and side projects on a single page. Inspired by the clarity and elegance of Read.cv, it highlights typography, whitespace, and straightforward navigation to showcase your work and experience effectively. It's ideal for designers, developers, and creatives seeking a digital presence that resembles a polished resume — but even stronger.

== Recommended Plugins ==

WP Dark Mode
Description: Dark Mode Plugin for Improved Accessibility, Dark Theme, Night Mode, and Social Sharing
Author: WPPOOL
Source: https://wordpress.org/plugins/wp-dark-mode/

== Fonts ==

Inter
Copyright 2016 The Inter Project Authors (https://github.com/rsms/inter)
License: This Font Software is licensed under the SIL Open Font License, Version 1.1.
License URI: This license is available with a FAQ at: https://openfontlicense.org
Source: https://rsms.me/

Manrope
Copyright 2019 The Manrope Project Authors (https://github.com/sharanda/manrope)
License: This Font Software is licensed under the SIL Open Font License, Version 1.1.
License URI: This license is available with a FAQ at: https://openfontlicense.org
Source: http://gent.media

EB Garamond
Copyright 2017 The EB Garamond Project Authors (https://github.com/octaviopardo/EBGaramond12)
License: This Font Software is licensed under the SIL Open Font License, Version 1.1.
License URI: This license is available with a FAQ at: https://openfontlicense.org
Source: http://georgduffner.at/

Plus Jakarta Sans
Copyright 2020 The Plus Jakarta Sans Project Authors (https://github.com/tokotype/PlusJakartaSans)
License: This Font Software is licensed under the SIL Open Font License, Version 1.1.
License URI: This license is available with a FAQ at: https://openfontlicense.org
Source: https://www.tokotype.com


== Images ==

Site logo (avatar) on screenshot
Lady in Yellow, by Dazyah
License: Public Domain, CC0 license.
License URI: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://nappy.co/photo/lady-in-yellowFiajBjZvhFhBS4PxPRYAM

Post image on screenshot
Wooden pole of a minor overhead power line, unidentified location.
License: Public Domain, CC0 license.
License URI: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://www.rawpixel.com/image/3286721/free-photo-image-electricity-public-domain-pole

