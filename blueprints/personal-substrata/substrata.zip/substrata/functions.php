<?php declare( strict_types = 1 ); ?>
<?php
/**
 * Substrata functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Substrata
 * @since Substrata 1.0
 */


if ( ! function_exists( 'substrata_support' ) ) :

	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * @since Substrata 1.0
	 *
	 * @return void
	 */
	function substrata_support() {

		// Enqueue editor styles.
		add_editor_style( 'style.css' );

		// Make theme available for translation.
		load_theme_textdomain( 'substrata' );
	}

endif;

add_action( 'after_setup_theme', 'substrata_support' );

if ( ! function_exists( 'substrata_styles' ) ) :

	/**
	 * Enqueue styles.
	 *
	 * @since Substrata 1.0
	 *
	 * @return void
	 */
	function substrata_styles() {

		// Register theme stylesheet.
		wp_register_style(
			'block_canvas-style',
			get_stylesheet_directory_uri() . '/style.css',
			array(),
			wp_get_theme()->get( 'Version' )
		);

		// Enqueue theme stylesheet.
		wp_enqueue_style( 'block_canvas-style' );

	}

endif;

add_action( 'wp_enqueue_scripts', 'substrata_styles' );
