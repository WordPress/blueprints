<?php
/**
 * Title: 404
 * Slug: substrata/404
 * Inserter: no
 */
?>
<!-- wp:group {"metadata":{"name":"Template wrapper"},"align":"wide","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="margin-top:0;margin-bottom:0"><!-- wp:template-part {"slug":"header","area":"header","align":"wide"} /-->

<!-- wp:group {"tagName":"main","metadata":{"name":"Content"},"align":"wide","layout":{"type":"constrained"}} -->
<main class="wp-block-group alignwide"><!-- wp:columns {"verticalAlignment":"top","align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|70"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-top"><!-- wp:column {"verticalAlignment":"top","width":"","layout":{"type":"default"}} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:heading {"textAlign":"left","level":1,"style":{"layout":{"selfStretch":"fill","flexSize":null},"typography":{"lineHeight":"1.1"}},"fontSize":"x-large"} -->
<h1 class="wp-block-heading has-text-align-left has-x-large-font-size" style="line-height:1.1"><?php /* Translators: 1. is a 'br' HTML element */ 
echo sprintf( esc_html__( 'This page was%1$snot found.', 'substrata' ), '<br>' ); ?></h1>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":""} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:group {"metadata":{"name":"Content block"},"layout":{"type":"constrained","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"align":"left"} -->
<p class="has-text-align-left"><?php esc_html_e('It looks like nothing was found at this location. Try a search.', 'substrata');?></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"var:preset|spacing|30","metadata":{"name":"XS"}} -->
<div style="height:var(--wp--preset--spacing--30)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:search {"label":"","showLabel":false,"buttonText":"","buttonPosition":"button-inside","buttonUseIcon":true} /-->

<!-- wp:spacer {"height":"var:preset|spacing|70","metadata":{"name":"XL"}} -->
<div style="height:var(--wp--preset--spacing--70)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"align":"left"} -->
<p class="has-text-align-left"><?php esc_html_e('Check out some of the topics I blog about:', 'substrata');?></p>
<!-- /wp:paragraph -->

<!-- wp:tag-cloud /--></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></main>
<!-- /wp:group -->

<!-- wp:template-part {"slug":"footer","area":"footer","align":"wide"} /--></div>
<!-- /wp:group -->