== Substrata ==

Contributors: Automattic
Requires at least: 6.8
Tested up to: 6.8
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Changelog ==

= 1.0.0 =
* Initial release


== Copyright ==

Substrata WordPress Theme, (C) 2025 Automattic
Substrata is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


Substrata is based on Observer (https://themeshaper.com/observer/), (C) Automattic, [GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)


== Description ==

Substrata is a minimalist blog or portfolio designed for researchers, writers, and storytellers working with field notes and reflective essays.

== Fonts ==

Crimson Pro
Copyright 2018 The Crimson Pro Project Authors (https://github.com/Fonthausen/CrimsonPro)
License: This Font Software is licensed under the SIL Open Font License, Version 1.1.
License URI: This license is available with a FAQ at: https://scripts.sil.org/OFL
Source: http://www.baronvonfonthausen.com/

Faculty Glyphic
Copyright 2024 The Faculty Glyphic Project Authors (https://github.com/DylanYoungKoto/FacultyGlyphic)
License: This Font Software is licensed under the SIL Open Font License, Version 1.1.
License URI: This license is available with a FAQ at: https://openfontlicense.org
Source: https://koto.studio/

Guggenheim Sans Display
License: This Font Software is licensed under the SIL Open Font License, Version 1.1.
License URI: This license is available with a FAQ at: https://openfontlicense.org
Source: https://www.guggenheim.org/press-release/guggenheim-unveils-new-visual-identity-uniting-its-global-constellation-of-museums

Open Sans & Open Sans Hebrew Condensed
Digitized data copyright © 2010-2011, Google Corporation.
License: Licensed under the Apache License, Version 2.0
Source: http://www.ascendercorp.com/

Playfair
Copyright 2005 The Playfair Project Authors (https://github.com/googlefonts/Playfair)
License: This Font Software is licensed under the SIL Open Font License, Version 1.1.
License URI: This license is available with a FAQ at: https://scripts.sil.org/OFL
Source: https://www.forthehearts.net/

Routed Gothic
Copyright (c) 2017, Darren Embry (http://webonastick.com/), with Reserved Font Name Routed Gothic.
License: This Font Software is licensed under the SIL Open Font License, Version 1.1.
License URI: This license is copied below, and is also available with a FAQ at: http://scripts.sil.org/OFL
Source: http://webonastick.com/

== Images ==

Portrait of the author on the screenshot
Woman with Peacock-Feather Fan by Arthur F Kales
License: Public Domain, CC0 license.
License URI: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://www.rawpixel.com/image/14254929/woman-with-peacock-feather-fan-arthur-kales


