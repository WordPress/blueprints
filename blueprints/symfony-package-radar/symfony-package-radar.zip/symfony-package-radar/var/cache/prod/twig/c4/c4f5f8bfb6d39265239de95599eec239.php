<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* dashboard.html.twig */
class __TwigTemplate_b970e9f09d91c316077d52190b4e0a06 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!doctype html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <title>Symfony Package Radar</title>
    <style>
        :root { color-scheme: light dark; }
        body { margin: 0; font-family: Inter, ui-sans-serif, system-ui, sans-serif; background: #111827; color: #f9fafb; }
        main { max-width: 1100px; margin: 0 auto; padding: 56px 24px; }
        .eyebrow { color: #fbbf24; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
        h1 { font-size: clamp(2.4rem, 6vw, 5rem); line-height: .95; margin: 12px 0; }
        h2 { margin-top: 48px; font-size: 1.8rem; }
        .lead { max-width: 760px; color: #d1d5db; font-size: 1.2rem; line-height: 1.7; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 18px; margin-top: 34px; }
        .card, .panel { background: #1f2937; border: 1px solid #374151; border-radius: 18px; padding: 22px; box-shadow: 0 24px 60px rgb(0 0 0 / 24%); }
        .card strong { color: #93c5fd; display: block; font-size: 1.05rem; margin-bottom: 10px; }
        .version { display: inline-flex; border-radius: 999px; background: #065f46; color: #d1fae5; padding: 4px 10px; font-size: .9rem; margin-bottom: 14px; }
        .features { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 28px; padding: 0; list-style: none; }
        .features li { border: 1px solid #4b5563; border-radius: 999px; padding: 8px 12px; color: #e5e7eb; }
        .steps { color: #d1d5db; line-height: 1.7; }
        .steps li { margin-bottom: 10px; }
        .source { overflow: auto; max-height: 680px; background: #0f172a; border: 1px solid #334155; border-radius: 18px; padding: 20px; }
        .source code { white-space: pre; }
        a { color: #93c5fd; }
        code { background: #0f172a; border-radius: 8px; padding: 2px 6px; }
    </style>
</head>
<body>
<main>
    <div class=\"eyebrow\">Symfony inside Playground</div>
    <h1>Package Radar</h1>
    <p class=\"lead\">
        This PHP-only demo uses Symfony\x27s attribute routing, service container,
        autowiring, Twig, and HttpClient. There is no WordPress download and no
        Node/Sass asset pipeline.
    </p>

    <ul class=\"features\">
        ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["features"]) || array_key_exists("features", $context) ? $context["features"] : (function () { throw new RuntimeError('Variable "features" does not exist.', 39, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["feature"]) {
            // line 40
            yield "            <li>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["feature"], "html", null, true);
            yield "</li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['feature'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        yield "    </ul>

    <section class=\"grid\" aria-label=\"Symfony package versions from Packagist\">
        ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["packages"]) || array_key_exists("packages", $context) ? $context["packages"] : (function () { throw new RuntimeError('Variable "packages" does not exist.', 45, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["package"]) {
            // line 46
            yield "            <article class=\"card\">
                <strong>";
            // line 47
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["package"], "name", [], "any", false, false, false, 47), "html", null, true);
            yield "</strong>
                <span class=\"version\">";
            // line 48
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["package"], "version", [], "any", false, false, false, 48), "html", null, true);
            yield "</span>
                <p>";
            // line 49
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["package"], "description", [], "any", false, false, false, 49), "html", null, true);
            yield "</p>
                <small>Release time: ";
            // line 50
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["package"], "time", [], "any", false, false, false, 50), "html", null, true);
            yield "</small>
            </article>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['package'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        yield "    </section>

    <section class=\"panel\">
        <h2>Try editing it</h2>
        <ol class=\"steps\">
            <li>Click <strong>Open Site Manager</strong> in the Playground toolbar.</li>
            <li>Open the <strong>File browser</strong> tab and edit <code>/wordpress/symfony-package-radar/src/Controller/DashboardController.php</code>.</li>
            <li>Open the <strong>Blueprint</strong> tab to inspect how this PHP-only Playground was created.</li>
            <li>Use the JSON route at <a href=\"index.php";
        // line 61
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("packages_json");
        yield "\"><code>index.php";
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("packages_json");
        yield "</code></a> to see the same controller return structured data.</li>
        </ol>
    </section>

    <h2>DashboardController.php</h2>
    <p class=\"lead\">
        This is the controller handling both the HTML dashboard and the JSON API route.
    </p>
    <div class=\"source\">";
        // line 69
        yield (isset($context["controllerSource"]) || array_key_exists("controllerSource", $context) ? $context["controllerSource"] : (function () { throw new RuntimeError('Variable "controllerSource" does not exist.', 69, $this->source); })());
        yield "</div>
</main>
</body>
</html>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "dashboard.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  151 => 69,  138 => 61,  128 => 53,  119 => 50,  115 => 49,  111 => 48,  107 => 47,  104 => 46,  100 => 45,  95 => 42,  86 => 40,  82 => 39,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "dashboard.html.twig", "/Users/cloudnik/conductor/workspaces/wordpress-playground/cairo/.context/symfony-package-radar-build/symfony-package-radar/templates/dashboard.html.twig");
    }
}
